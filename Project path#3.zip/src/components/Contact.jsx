import React from 'react'

function Contact() {
  return (
    <div className='main'>Contact</div>
  )
}

export default Contact