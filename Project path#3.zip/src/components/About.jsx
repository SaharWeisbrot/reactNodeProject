import React from 'react'

function About() {
  return (
    <div className='main'>About</div>
  )
}

export default About