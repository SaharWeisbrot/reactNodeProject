import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../assets/styles/AddCategory.css";

function AddCategory() {
  const navigate = useNavigate();

  const [addCategory, setAddCategory] = useState({
    title: "",
    content: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAddCategory((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (addCategory.title && addCategory.content) {
      try {
        const response = await axios.post(
          "http://localhost:8801/categories",
          addCategory
        );
        console.log("Category added:", response.data);
        navigate("/");
      } catch (error) {
        console.error("Error adding category:", error);
      }
    } else {
      alert("נא למלא את כל השדות.");
    }
  };

  return (
    <div className="main">
      <h2>הוסף קטגוריה חדשה</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>שם הקטגוריה:</label>
          <input
            type="text"
            name="title"
            value={addCategory.title}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>תיאור הקטגוריה:</label>
          <textarea
            name="content"
            value={addCategory.content}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">הוסף</button>
      </form>
    </div>
  );
}

export default AddCategory;
