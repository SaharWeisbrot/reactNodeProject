import React from "react";

function Footer() {
  return (
    <footer>
      <div className="container ">
        <div className="footer__wrap"></div>
      </div>
      סהר ויסברוט
    </footer>
  );
}

export default Footer;
