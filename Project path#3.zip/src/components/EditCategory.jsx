import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import "../assets/styles/AddCategory.css";

function EditCategory() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [editCategory, setEditCategory] = useState({
    title: "",
    content: "",
  });

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchCategory = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8801/categories/${id}`
        );
        setEditCategory(response.data);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching category:", error);
        setIsLoading(false);
      }
    };
    fetchCategory();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditCategory((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editCategory.title && editCategory.content) {
      try {
        const response = await axios.put(
          `http://localhost:8801/categories/${id}`,
          editCategory
        );
        console.log("Category updated:", response.data);
        navigate("/");
      } catch (error) {
        console.error("Error updating category:", error);
      }
    } else {
      alert("נא למלא את כל השדות.");
    }
  };

  if (isLoading) {
    return <div>טוען...</div>;
  }

  return (
    <div className="main">
      <h2>ברצונך לערוך קטגוריה לשם הבא - {editCategory.title}</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>שם קטגוריה חדש:</label>
          <input
            type="text"
            name="title"
            value={editCategory.title}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>תיאור קטגוריה חדש:</label>
          <textarea
            name="content"
            value={editCategory.content}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">עדכן</button>
      </form>
    </div>
  );
}

export default EditCategory;
