const express = require("express");
const router = express.Router();
const dbSingleton = require("../dbSingleton");

// Execute a query to the database
const db = dbSingleton.getConnection();

// Get all categories
router.get("/", (req, res) => {
  const query = "SELECT id, title, content FROM categories";
  db.query(query, (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    res.json(results);
  });
});

// Add a new category
router.post("/", (req, res) => {
  const { title, content } = req.body;
  if (!title || !content) {
    return res.status(400).json({ error: "Title and content are required" });
  }
  const query = "INSERT INTO categories (title, content) VALUES (?, ?)";
  db.query(query, [title, content], (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    res.json({ message: "Category added!", id: results.insertId });
  });
});

// Update an existing category
router.put("/:id", (req, res) => {
  const { id } = req.params;
  const { title, content } = req.body;
  if (!title || !content) {
    return res.status(400).json({ error: "Title and content are required" });
  }
  const query = "UPDATE categories SET title = ?, content = ? WHERE id = ?";
  db.query(query, [title, content, id], (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    res.json({ message: "Category updated!" });
  });
});

// Delete a category
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM categories WHERE id = ?";
  db.query(query, [id], (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    res.json({ message: "Category deleted!" });
  });
});

module.exports = router;
